package com.tacz.guns.compat.ar;

public record BeamRenderContext(float z, float width, boolean fadeOut) {

}
