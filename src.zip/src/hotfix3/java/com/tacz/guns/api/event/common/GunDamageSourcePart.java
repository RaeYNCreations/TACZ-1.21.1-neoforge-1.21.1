package com.tacz.guns.api.event.common;

public enum GunDamageSourcePart {
    NON_ARMOR_PIERCING,
    ARMOR_PIERCING,
}
