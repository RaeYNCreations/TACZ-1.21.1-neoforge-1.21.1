package com.tacz.guns.client.resource.pojo.display.gun;

import com.google.gson.annotations.SerializedName;

public enum Align {
    @SerializedName("left")
    LEFT,
    @SerializedName("center")
    CENTER,
    @SerializedName("right")
    RIGHT
}
