package com.tacz.guns.client.resource.pojo.display.gun;

import com.google.gson.annotations.SerializedName;

public enum DefaultAnimationType {
    @SerializedName("rifle")
    RIFLE,
    @SerializedName("pistol")
    PISTOL
}
